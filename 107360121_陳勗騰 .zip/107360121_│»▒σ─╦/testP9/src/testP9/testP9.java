package testP9;

public class testP9 
{
	public static void main(String[] args) 
	{
		System.out.print("�w�Ȩϥ�Java!");
		System.out.print("�}�l�ϥ�Java�a!");
	}
}
